export const environment = {
  nodeEnv: "production",
  production: true,
  apiVersion: "/api/v1/",
  apiHost: "https://oportunidappv2-api-pp.n-techlab.xyz",
  usagePolicies:
    "https://oportunidapp-data.s3.amazonaws.com/Legal/OportunidApp_PoliticasDeUsoDatos.pdf",
  termsAndConditions:
    "https://oportunidapp-data.s3.amazonaws.com/Legal/OportunidApp_TyC.pdf",
  ytIdPreInterviews: "uzVG7aVQuQ8",
};

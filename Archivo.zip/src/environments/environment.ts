export const environment = {
    nodeEnv: 'development',
    production: false, 
    apiVersion: '/api/v1/', 
    apiHost: 'https://oportunidappv2-api-pp.n-techlab.xyz',
    apiEvalHost: 'https://apim-evaluatestia-prod-001.azure-api.net/',
    apiEmpHost: 'https://apiempresas.evaluatest.com',
    usagePolicies: 'https://oportunidapp-data.s3.amazonaws.com/Legal/OportunidApp_PoliticasDeUsoDatos.pdf',
    termsAndConditions: 'https://oportunidapp-data.s3.amazonaws.com/Legal/OportunidApp_TyC.pdf', 
    ytIdPreInterviews: 'uzVG7aVQuQ8',
    socketApplymentStatus: '7aByKt2ZN&vdBT'
}
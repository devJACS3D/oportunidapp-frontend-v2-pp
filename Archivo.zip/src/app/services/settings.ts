
export enum AppSettings {
    defaultItemsPerPage = 9
}
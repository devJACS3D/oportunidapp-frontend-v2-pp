import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-success-case',
  templateUrl: './success-case.component.html',
  styleUrls: ['./success-case.component.scss']
})
export class SuccessCaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

export enum NAMESPACES {
  CHATS = "chats",
  CHAT_BOT = "chatBot",
  VCY_APPLYMENT_STATUSES = "vacancyApplymentStatuses"
}

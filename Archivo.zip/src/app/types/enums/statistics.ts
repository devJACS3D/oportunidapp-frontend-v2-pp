export enum STATISTICS {
  VACANCY_USERS = "vacancyUsers",
  VACANCY_COMPANIES = "vacancyCompanies",
  REGISTERED_USERS = "registeredUsers",
  REGISTERED_COMPANIES = "registeredCompanies",
  QUALIFIED_CANDIDATES = "qualifiedCandidates",
  QUALIFIED_PLATFORM = "qualifiedPlatform"
}

export enum QUALIFY {
    CANDIDATES,
    PLATFORM,
  }
  
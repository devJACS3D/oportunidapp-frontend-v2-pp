
export enum FiltersFor {
  ADMIN,
  USER,
}

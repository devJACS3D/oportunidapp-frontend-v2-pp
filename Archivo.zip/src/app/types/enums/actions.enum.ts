
export enum ACTIONS {
    CREATE,
    EDIT,
    DETAIL,
    REMOVE,
    SCHEDULE
}
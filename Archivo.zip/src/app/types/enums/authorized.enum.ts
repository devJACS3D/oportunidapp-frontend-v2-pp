export enum AUTHORIZED {
    BUSINESS = 'isBusinessProfile',
    PSYCHOLOGIST = 'isPsychologistProfile',
    ADMIN = 'isAdminProfile',
    USER = 'isAgentProfile',
}


export enum FilterType {
    "vacancyFilters" = "filters.v",
    "userFilters" = "filters.u",
    "candidateFilters" = "filters.c",
    "vacancyApplymentFilters" = "filters.vapp",
    "requisitionFilters" = "filters.r",
}
export enum applymentStatus {
    STAND = 1,
    PRE_INTERVIEW = 2,
    PSYCHOTECH_TEST = 3,
    INTERVIEW = 4,
    BACKGROUND_CHECK = 5,
    REF_BACKGROUND_CHECK = 6,
    TECH_INTERVIEW = 7,
    COMPETENT = 8
}

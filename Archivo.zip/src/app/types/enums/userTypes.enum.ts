export enum UserTypes{
    ADMIN = 1,
    PSYCHOLOGY = 2,
    BUSINESS = 3,
    AGENT = 4,
}
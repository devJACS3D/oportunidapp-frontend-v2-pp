export interface image {
	Name?: string;
	Url?: any;
	Data?: string;
}

export interface IFile {
	Name?: string;
	Data?: any;
	Location?: any;
}
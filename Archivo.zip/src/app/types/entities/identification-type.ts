export interface IIdentificationType {
  id: number;
  name: string;
  createdAt?: any;
  updatedAt?: any;
  deletedAt?: any;
}

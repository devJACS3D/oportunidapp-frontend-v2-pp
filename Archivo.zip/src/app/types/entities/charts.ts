

export interface IProgressChartDataSet{
    label: string,
    progress: number,
    tooltip?: string
}
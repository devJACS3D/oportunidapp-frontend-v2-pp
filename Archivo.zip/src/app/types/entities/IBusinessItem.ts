export interface BusinessItem{
    name: string,
    url: string,
    description: string,
    image: string,
    mission?: string,
    vision?: string,
    principles?: string,
}
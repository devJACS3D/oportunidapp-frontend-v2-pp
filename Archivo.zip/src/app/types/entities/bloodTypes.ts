export interface IBloodTypes {
    id: number;
    description: string;
}

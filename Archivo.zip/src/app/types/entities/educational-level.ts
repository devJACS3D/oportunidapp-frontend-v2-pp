// Niveles de estudio
export interface IEducationalLevel {
    id: number;
    name: string;
}

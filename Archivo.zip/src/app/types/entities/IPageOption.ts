

export interface IPageOption{
    page:number,
    filters?: object
}
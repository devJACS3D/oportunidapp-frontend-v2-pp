export interface IS3Files {
    path: string;
    name: string;
}

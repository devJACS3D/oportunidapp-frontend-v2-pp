export interface IServiceType {
  id: number;
  name: string;
  createdAt: string;
  updatedAt: string;
  deletedAt: string;
}

export interface IPost {
    id?: number;
    name: string;
    author: string;
    description: string;
    aboutAuthor: string;
    images?: any;
}

export interface ICivilStatus {
    id: number;
    name: string;
}

export interface PreviewCardItem{
    id: number,
    title: string;
    description: string;
    image: string;
}
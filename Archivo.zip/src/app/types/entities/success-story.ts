export interface ISuccessStory {
    id?: number;
    name: string;
    comment: string;
    images?: any;
    video: string;
    rol: string;
    createdAt?: string;
    updatedAt?: string;
    deletedAt?: string;
}

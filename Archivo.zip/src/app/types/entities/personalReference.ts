export interface IPersonalReference {
    id: number;
    name: string;
    occupation: string;
    relationship: string;
    cellphone: string;
    address: string
}

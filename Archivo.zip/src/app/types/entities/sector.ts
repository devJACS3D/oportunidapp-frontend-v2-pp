export interface ISector {
    id?: number;
    name: string;
    description: string;
    createdAt?: any;
    updatedAt?: any;
    deletedAt?: any;
}
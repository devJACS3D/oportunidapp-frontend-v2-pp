export interface IContractType {
    id: number;
    name: string;
}

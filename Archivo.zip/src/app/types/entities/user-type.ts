export interface IUserType {
    id: number;
    name: string;
}

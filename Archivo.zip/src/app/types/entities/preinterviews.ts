export interface IPreinterviews {
    id: number;
    name: string;
    question: string;
    approved: boolean;
    vacancies: any[]
    default: boolean;
    updatedAt: string
}
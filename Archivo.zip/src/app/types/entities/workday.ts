export interface IWorkday {
    id: number;
    name: string;
}

export interface IDrivingLicense {
    id: number;
    name: string;
}

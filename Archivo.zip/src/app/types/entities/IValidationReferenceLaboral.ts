interface IValidationReferenceLaboral {
  approved: boolean;
  comment: string;
  createdAt: string;
  deletedAt?: any;
  id: number;
  laboralExpe: number;
  updatedAt: string;
  userId: number;
  vacancyId: number;
}

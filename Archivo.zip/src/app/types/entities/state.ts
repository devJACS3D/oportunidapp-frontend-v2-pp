export interface IState {
    id: number;
    name: string;
}

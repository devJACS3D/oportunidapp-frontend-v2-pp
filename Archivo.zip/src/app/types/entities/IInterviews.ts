export interface IInterview {
    
}
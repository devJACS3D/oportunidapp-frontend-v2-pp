import { IUser } from "./IUser";

export interface ISuperUser extends IUser {
    name: string;
}
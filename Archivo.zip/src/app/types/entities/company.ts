export interface ICompany {
  idPadEval: any;
  emailContact: string;
  id: number;
  name: string;
}

export interface ICost {
    id?: any;
    rangoInferior: any;
    rangoSuperior: any;
    rango1: any;
    rango2: any;
    rango3: any;
    rango4: any;
    createdAt?: any;
    updatedAt?: any;
    deletedAt?: any;
}
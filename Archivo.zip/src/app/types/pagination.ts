export interface IPagination {
    pages: number[];
    pagesNumber: number;
    elementsNumber: number;
    itemsPerPage: number;
    currentPage: number
}
import { IUser } from "./entities/IUser";
import { IBusiness } from "./entities/IBusiness";

export type LoggedUser = IUser | IBusiness

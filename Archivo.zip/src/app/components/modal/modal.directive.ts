import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[modalContent]'
})
export class ModalDirective {

  constructor(public viewContainerRef: ViewContainerRef) { }

}
